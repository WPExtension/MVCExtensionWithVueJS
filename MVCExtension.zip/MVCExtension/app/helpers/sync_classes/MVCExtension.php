<?php 

class MVCExtension {

    
}