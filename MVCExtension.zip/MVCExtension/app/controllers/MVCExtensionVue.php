<?php 
namespace PHPAutoloader\Classes\controllers;

use \PHPAutoloader\Classes\libraries\Controller;

class MVCExtensionVue extends Controller {

   public function __construct() {

      add_action('setting_vue', [$this,'setting_vue_app']);
     
   }
   
   public function setting_vue_app() {

      $this->view('pages/Vue', [

        'title' => 'message',
        'description' => 'vueDescription'  

      ]);

   }

 
}

