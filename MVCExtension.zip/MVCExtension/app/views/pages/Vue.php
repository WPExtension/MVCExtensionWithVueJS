<?php app_get_header('header'); ?>

<div id="appTest">{{ <?php echo $data['title'];  ?> }}</div>
<p id="para">{{ <?php echo $data['description'];  ?> }}</p>

<?php app_get_footer('footer'); ?>